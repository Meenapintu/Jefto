------------------
CSS3 Charts
A CSS3+(X)HTML-based template.
Designed by Sean Oh (http://www.ohsean.net) from USA.
Pure CSS3 experimental charts. Best viewed in Webkit browsers.
------------------

Dear friends,

thank you for downloading this file.

You can freely use this template for both your private and commercial projects, including software, online services, templates and themes.